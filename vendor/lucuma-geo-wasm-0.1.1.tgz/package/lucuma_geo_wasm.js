/* @ts-self-types="./lucuma_geo_wasm.d.ts" */

/**
 * Affine transform: `x' = m00*x + m01*y + m02`, `y' = m10*x + m11*y + m12`.
 * @param {number} h
 * @param {number} m00
 * @param {number} m01
 * @param {number} m02
 * @param {number} m10
 * @param {number} m11
 * @param {number} m12
 * @returns {number}
 */
export function affine(h, m00, m01, m02, m10, m11, m12) {
    const ret = wasm.affine(h, m00, m01, m02, m10, m11, m12);
    return ret >>> 0;
}

/**
 * JTS `GeometricShapeFactory.createArcPolygon`: centre, `npts` points along the arc from
 * `start` over `extent` radians (full circle when extent is out of range), back to centre.
 * @param {number} x0
 * @param {number} y0
 * @param {number} x1
 * @param {number} y1
 * @param {number} start
 * @param {number} extent
 * @param {number} npts
 * @returns {number}
 */
export function arc_new(x0, y0, x1, y1, start, extent, npts) {
    const ret = wasm.arc_new(x0, y0, x1, y1, start, extent, npts);
    return ret >>> 0;
}

/**
 * @param {number} h
 * @returns {number}
 */
export function area(h) {
    const ret = wasm.area(h);
    return ret;
}

/**
 * `[minx, miny, maxx, maxy]`, all NaN when empty.
 * @param {number} h
 * @returns {Float64Array}
 */
export function bbox(h) {
    const ret = wasm.bbox(h);
    var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
    return v1;
}

/**
 * @param {number} h
 * @param {number} x
 * @param {number} y
 * @returns {boolean}
 */
export function contains_point(h, x, y) {
    const ret = wasm.contains_point(h, x, y);
    return ret !== 0;
}

/**
 * Flat `x,y` coordinates of every exterior ring, concatenated. Enough for a radius or a plot.
 * @param {number} h
 * @returns {Float64Array}
 */
export function coords(h) {
    const ret = wasm.coords(h);
    var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
    return v1;
}

/**
 * JTS `GeometricShapeFactory.createEllipse` from a bounding box: `npts` points starting at
 * angle 0, closed on the first point.
 * @param {number} x0
 * @param {number} y0
 * @param {number} x1
 * @param {number} y1
 * @param {number} npts
 * @returns {number}
 */
export function ellipse_new(x0, y0, x1, y1, npts) {
    const ret = wasm.ellipse_new(x0, y0, x1, y1, npts);
    return ret >>> 0;
}

/**
 * @returns {number}
 */
export function empty_new() {
    const ret = wasm.empty_new();
    return ret >>> 0;
}

/**
 * @param {number} h
 */
export function free(h) {
    wasm.free(h);
}

/**
 * @param {number} a
 * @param {number} b
 * @returns {boolean}
 */
export function intersects(a, b) {
    const ret = wasm.intersects(a, b);
    return ret !== 0;
}

/**
 * Number of live handles; a leak detector for the facade's tests.
 * @returns {number}
 */
export function live() {
    const ret = wasm.live();
    return ret >>> 0;
}

/**
 * Boolean overlay. `kind`: 0 intersection, 1 union, 2 difference.
 * @param {number} kind
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
export function op(kind, a, b) {
    const ret = wasm.op(kind, a, b);
    return ret >>> 0;
}

/**
 * Flat closed ring `x0,y0,x1,y1,...`; the caller closes the ring.
 * @param {Float64Array} coords
 * @returns {number}
 */
export function poly_new(coords) {
    const ptr0 = passArrayF64ToWasm0(coords, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.poly_new(ptr0, len0);
    return ret >>> 0;
}

/**
 * @param {number} x0
 * @param {number} y0
 * @param {number} x1
 * @param {number} y1
 * @returns {number}
 */
export function rect_new(x0, y0, x1, y1) {
    const ret = wasm.rect_new(x0, y0, x1, y1);
    return ret >>> 0;
}

/**
 * Self-describing ring dump for plotting: `[nPolygons, (nRings, (nPoints, x, y, ...)*)*]`.
 * The first ring of each polygon is its exterior, the rest are holes. Rings are closed.
 * @param {number} h
 * @returns {Float64Array}
 */
export function rings(h) {
    const ret = wasm.rings(h);
    var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
    return v1;
}

/**
 * Semver of this kernel, for the facade's compatibility check.
 * @returns {string}
 */
export function version() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.version();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./lucuma_geo_wasm_bg.js": import0,
    };
}

function getArrayF64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedFloat64ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('lucuma_geo_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
