/* tslint:disable */
/* eslint-disable */

/**
 * Affine transform: `x' = m00*x + m01*y + m02`, `y' = m10*x + m11*y + m12`.
 */
export function affine(h: number, m00: number, m01: number, m02: number, m10: number, m11: number, m12: number): number;

/**
 * JTS `GeometricShapeFactory.createArcPolygon`: centre, `npts` points along the arc from
 * `start` over `extent` radians (full circle when extent is out of range), back to centre.
 */
export function arc_new(x0: number, y0: number, x1: number, y1: number, start: number, extent: number, npts: number): number;

export function area(h: number): number;

/**
 * `[minx, miny, maxx, maxy]`, all NaN when empty.
 */
export function bbox(h: number): Float64Array;

export function contains_point(h: number, x: number, y: number): boolean;

/**
 * Flat `x,y` coordinates of every exterior ring, concatenated. Enough for a radius or a plot.
 */
export function coords(h: number): Float64Array;

/**
 * JTS `GeometricShapeFactory.createEllipse` from a bounding box: `npts` points starting at
 * angle 0, closed on the first point.
 */
export function ellipse_new(x0: number, y0: number, x1: number, y1: number, npts: number): number;

export function empty_new(): number;

export function free(h: number): void;

export function intersects(a: number, b: number): boolean;

/**
 * Number of live handles; a leak detector for the facade's tests.
 */
export function live(): number;

/**
 * Boolean overlay. `kind`: 0 intersection, 1 union, 2 difference.
 */
export function op(kind: number, a: number, b: number): number;

/**
 * Flat closed ring `x0,y0,x1,y1,...`; the caller closes the ring.
 */
export function poly_new(coords: Float64Array): number;

export function rect_new(x0: number, y0: number, x1: number, y1: number): number;

/**
 * Semver of this kernel, for the facade's compatibility check.
 */
export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly affine: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly arc_new: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly area: (a: number) => number;
    readonly bbox: (a: number) => [number, number];
    readonly contains_point: (a: number, b: number, c: number) => number;
    readonly coords: (a: number) => [number, number];
    readonly ellipse_new: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly empty_new: () => number;
    readonly free: (a: number) => void;
    readonly intersects: (a: number, b: number) => number;
    readonly live: () => number;
    readonly op: (a: number, b: number, c: number) => number;
    readonly poly_new: (a: number, b: number) => number;
    readonly rect_new: (a: number, b: number, c: number, d: number) => number;
    readonly version: () => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
